//============================================================================
// Name        : GarrisonClient.cpp
// Author      : Stoyan
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <unistd.h>
#include <netdb.h>
#include <string.h>
#include <strings.h>
using namespace std;



int main(int argc, char *argv[]) {

	int sock;
	int receiver;
	struct sockaddr_in serverAddress;
	struct hostent *server;
	char readBuffer[256];
	int sender;
	char* targetServerAddress = argv[1];
	int port = atoi(argv[2]);

	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0)
	{
		std::cout << "Error creating socket!" << std::endl;
		return 1;
	}

	server = gethostbyname(targetServerAddress);
	bzero((char*) &serverAddress, sizeof(serverAddress));
	serverAddress.sin_family = AF_INET;

	bcopy((char*) server->h_addr, (char*) &serverAddress.sin_addr.s_addr, server->h_length);
	serverAddress.sin_port = htons(port);

	if (connect(sock, (struct sockaddr*) &serverAddress, sizeof(serverAddress)) < 0)
	{
		std::cout << "Connection failed!" << std::endl;
		return 1;
	}

	std::cout << "Enter message: ";
	bzero(readBuffer, 256);
	fgets(readBuffer, 255, stdin);
	readBuffer[strlen(readBuffer) - 1] = '\0';

	sender = send(sock, readBuffer, strlen(readBuffer), 0);

	if(sender < 0)
	{
		std::cout << "Error sending message!" << std::endl;
		return 1;
	}

	bzero(readBuffer, 256);

	receiver = recv(sock, readBuffer, 255, 0);
	if (receiver < 0)
	{
		std::cout << "Error reading!" << std::endl;
		return 1;
	}

	printf("Received message: %s\n", readBuffer);

	close(sock);
	return 0;
}
