//============================================================================
// Name        : GarrisonServer.cpp
// Author      : Stoyan
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#define CRYPTOPP_ENABLE_NAMESPACE_WEAK 1
#include <iostream>
#include <arpa/inet.h>
#include <unistd.h>
#include "cryptopp/sha.h"
#include "cryptopp/hex.h"
using namespace std;

typedef uint8_t byte;
int const MAX_THREADS = 20;

void *processThread(void* arg)
{
	int currentSocket = *((int*) arg);
	char readBuffer[256];
	int reader;
	if (currentSocket < 0)
		std::cout << "Error accepting!" << std::endl;
	reader = recv(currentSocket, readBuffer, 255, 0);
	if (reader < 0)
		std::cout << "Error reading!" <<std::endl;

	std::string originalMessage(readBuffer);
	std::string encryptedMessage = "";

	std::string loopMessage(originalMessage);
	for(int i = 0; i < 10000; i++)
	{
		encryptedMessage = "";
		CryptoPP::SHA1 sha1;
		CryptoPP::StringSource(loopMessage, true, new CryptoPP::HashFilter(sha1, new CryptoPP::HexEncoder(new CryptoPP::StringSink(encryptedMessage))));
		loopMessage = encryptedMessage;
	}

	char* messageToSend = const_cast<char*>(encryptedMessage.c_str());

	int sender = send(currentSocket, messageToSend, 255, 0);
	if (sender < 0)
		printf("Error sending - %d\n", currentSocket);

	close(currentSocket);
	delete[] ((int*) arg);
	pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
	int sock;
	int newSock;
	int port;

	port = atoi(argv[1]);
	socklen_t clientAddressSize;
	struct sockaddr_in serverAddress, clientAddress;

	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0)
	{
		std::cout << "Socket creation failed!" << std::endl;
		return 1;
	}

	bzero((char*) &serverAddress, sizeof(serverAddress));
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = INADDR_ANY;
	serverAddress.sin_port = htons(port);

	if (bind(sock, (struct sockaddr*) &serverAddress, sizeof(serverAddress)) < 0)
	{
		std::cout << "Socket binding failed!" << std::endl;
		return 1;
	}

	if (listen(sock, MAX_THREADS) < 0)
	{
		std::cout << "Error listening!" << std::endl;
		return 1;
	}

	pthread_t threads[MAX_THREADS];
	int threadIndex = 0;
	clientAddressSize = sizeof(clientAddress);
	while(1)
	{
		newSock = accept(sock, (struct sockaddr*) &clientAddress, &clientAddressSize);
		int* pSocket = new int(newSock);

		if (pthread_create(&threads[threadIndex++], NULL, processThread, pSocket) != 0)
			std::cout << "Thread creation failed!" << std::endl;

		if (threadIndex >= MAX_THREADS)
		{
			int i = 0;
			while (i < MAX_THREADS)
			{
				pthread_join(threads[i++], NULL);
			}
			threadIndex = 0;
		}
	}

	close(sock);
	return 0;
}
